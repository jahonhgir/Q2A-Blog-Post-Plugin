BLOG POST PLUGIN README
=============

The Blog module allows registered users to maintain an online journal, or blog. Blogs are made up of individual blog entries. By default, the blog entries are displayed by creation time in descending order.

FEATURES OF THE BLOG POST PLUGIN
1. There are currently 5 categories by default in this plugin.
2. All registred users can post a new articles.
3. The blog homepage displays latest posts with their authors, date and number of views.
4. It uses the editor selected for the questions to post new articles.
5. No limit for content
6. Adds a new menu item on the user pages to link to the user's articles.



REQUIREMENTS 
1. Question2Answer 1.5 and over.
2. Markdown Editor to display articles after they are posted.


INSTALLATION 
1. Download the blog post plugin from the download link indicated.
2. Extract the files to your location of choice on your computer.
3. Go to plugins >> and locate the blog post plugin. YOU MUST CONFIGURE IT FIRST SO THAT IT CAN WORK!
9. Then you can now use it as you wish.


